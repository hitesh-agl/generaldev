
### Description
This module of terraform allows you to deploy simple vnet on Azure using SPN 

### Usage
To run locally 
1. clone this repo/pacakge 
2. from the pacakage directory , terraform init, terraform plan, terraform apply. to remove it use terraform destroy. 
## Requirements
Azure SPN with clientid and secret
Azure access 
Terraform 
Network Contributor role to SPN

## Providers
Terraform , Azure 

## Modules
terraform-azzurerm-vnet


### Running locally 
Please put SPN details in providers.tf file if you are running locally from your laptop