# Pull Request Process
1. Every contributor creates a release branch for a specific feature/task from the main branch.
2. Name the feature branch based on the following convention "**feature id - github handle/team**" 
    - git checkout -b **branch name**
3. User Correct Folder Structure + Naming Conventions(read namingconvention.md for more details)
4. After development is complete the code/script/module should be runnable locally or by another reviewer 
5. Pull the code main branch to local before commiting changes to avoid merge conflicts
6. Commit code to feature branch follow best practices.
     -  Make small and single purpose commit
     -  Write short and detailed Commit message.
     -  Follow the [link](https://chris.beams.io/posts/git-commit) to write good commit messages
7. Push to git feature branch.
8. Create pull request.

# After Pull Request submitted (TBC)
1. Automated end to end testing for the TF module will be commence.
2. Upon successful automated testing, PR will be release for review by Maintainers (<link to maintainers team>)
3. Upon successful Review, Maintainer will approve and perform Release tag.


# Overall process flow
Repo - > Clone -> Branch -> Develop -> Push -> Review -> Merge 

# PACKAGES 
All the code/modules are subdirectories under **packages** folder , as a best practice lets follow **infra-tf-azrm-<component>** for example infra-tf-azrm-vnet. If this is a service or some other development , then service-aks-webui or service-aks-backend or datafoundation-sql-backend, datafoundataion-python-frontend. 


# README.md 

Include README.md for each package with brief description of what the package does and how can a person run this or debug this in your absence 

