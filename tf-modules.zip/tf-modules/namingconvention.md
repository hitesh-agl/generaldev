The GCP resources in Aspekt+ will follow a naming convention which helps identify the purpose of the resource and allows a uniformity in the taxonomy defined within the platform. This document outlines the naming convention format to be followed.

<h2>Guidance for Naming Convention</h2>
The below rules must be followed for the naming set for any resource.

1. The length of characters should be between 1-63. 
2. Match the regular expression [a-z]([-a-z0-9]*[a-z0-9])?. This means that the first character must be a lowercase letter, and all the following characters must be hyphens, lowercase letters, or digits, except the last character, which cannot be a hyphen.

<h2> Aspekt+ Naming Convention </h2>
The general naming convention format should be set as:
**[tenant]-[program]-[resource]-[region]-[purpose]-[name]-[uid]**

The meaning of the above convention is as follows:

**tenant **- An acronym for the client or entity for which the deployment has been used. Eg. for Deloitte NSE it would be `dnse`. This acronym can be decided for a given tenant's deployment to identify the resource has part of the tenant. 

**program** - The name of the program which may differ from Aspekt+. In case of Aspekt+ it will be `aspektp`. Client's may have a different program name which should go in here.

**resource** - The acronym for the GCP resource the name refers to, for eg. GCS bucket or BigQuery dataset etc. Refer to the table below for the resource acronyms. 

**region** - The region for the resource to be provisioned in. Refer to the acronym list below for the regions in use. Where region is not applicable eg. on serverless resources like Cloud Run, Cloud Functions or AppEngine omit the region setting.

**purpose** - The business purpose of the resource which is being created. The purpose should highlight a use case or business goal of which the resource is a part of. For eg. Openbanking use case can be a purpose and any resource created for this solution should have a short acronym for it. 

**name** - A short name of the resource to be provisioned. 

**uid** - This is a unique id given to a resource as a suffix which can be a random 2 digit number or a serially incrementing number like 01, 02, 03 etc.

Eg. Bronze Layer GCS bucket on Aspekt+ for Company House use case : 
> dnse-aspektp-stb-euwe2-bnz-cmphouse-01

Eg. BigQuery Dataset on Aspekt+ at Silver Layer for OpenBanking use case : 
> dnse-aspektp-bqd-euwe2-slv-openbnk-01

Eg. A Cloud Run deployment on Aspekt+ for MLFlow for OpenBanking use case : 
> dnse-aspektp-crun-euwe2-mlf-openbnk-01

<h3> GCP Resource Acronym </h3>

| Resource| Acronym|
| ------ | ------ |
| Storage Buckets| stb|
| BigQuery Dataset| bqd|
| BigQuery Table| bqt|
| BigQuery View| bqv|
| Kubernetes| gke|
| Cloud KMS| kms|
| Cloud SQL| csql|
| Compute Engine| ce|
| Cloud Functions| cf|
| Dataproc Cluster| dcl|
| Dataflow Job| dfl|
| Data Catalog| dct|
| Cloud DLP| dlp|
| Kafka Cluster| kcl|
| Kafka Topic| ktop|
| Cloud Run Deployment| crun|
| MLFlow | mlf|

<h3> GCP Region Acronym </h3>

| Region| Acronym|
| ------ | ------ |
| europe-west2| euwe2|
| europe-west1| euwe1|
| europe-west3| euwe3|

<h2>Aspekt+ Naming Convention - Azure</h2>
The restrictions on naming individual components in Azure are specific to the individual components. In order to be as consistent as possible a limit of 25 characters has been adopted.

An example component is:-
Eg. A Logic App in Aspekt+ for Company House use case : 
> azsb-ap-la-uks-dev-ch-01 

Eg. A Storage Acccount in Aspekt+ for Company House use case :
NB - dashes are not permitted in storage account names 
> azsbapstuksdevch01

<h3> Azure Resource Acronym </h3>

| Resource| Acronym|
| ------ | ------ |
| Azure Cognitive Services| cog|
| Azure Data Factory| adf|
| Container Registry| cr|
| Databricks Workspace| dbw|
| Event Hub| evh|
| Function App| fca|
| HDInsight - Kafka| kfk|
| Key Vault| kv|
| Kubernetes| aks|
| Logic Apps| lga|
| MLFlow | mlf|
| Purview| pv|
| Resource Group| rg|
| Storage Account| st|
| SQL Database Server| sqls|
| SQL Database| sql|
| Virtual Machine| vm|
| Virtual Network| vn|
| Virtual Network Subnet| sn|
| VPN Gateway| vg|

More abbreviations can be found here:- 
https://docs.microsoft.com/en-us/azure/cloud-adoption-framework/ready/azure-best-practices/resource-abbreviations

<h3> Azure Region Acronym </h3>

| Region| Acronym|
| ------ | ------ |
| UK South| uks|
| UK West| ukw|
| West Europe| weu|

<h3>Business Purpose Shortcodes </h3>

| Business Purpose| Acronym|
| ------ | ------ |
| Bronze Layer| bnz|
| Silver Layer| slv|
| Gold Layer| gld|
| Data Transformation| trans|
| Data Aggregation| aggr|
| Model Training| train|
| Web Interface| webgw|

<h4> Use case Shortcodes </h4>

| Use Cases| Acronym|
| ------ | ------ |
| Company House| cmphouse|
| OpenBanking| openbnk|
| LTS NLP| ltsnlp|
| Statement of Value| sov|


azsb-ap-la-uks-dev-ch-01

AKS:azsb-ap-aks-uks-dev-ch-01
StorageAccount:azsbapsauksdevch01
VirtualNetwork:azsb-ap-vn-uks-dev-ch-01
SQL DB: azsb-ap-sql-uks-dev-ch-01
SQL Server: azsb-ap-sql-uks-dev-ch-01
Container Registry: azsb-ap-cr-uks-dev-ch-01


