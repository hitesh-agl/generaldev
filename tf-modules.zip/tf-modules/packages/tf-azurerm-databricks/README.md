### Terraform gitHub documentation [link](https://github.com/terraform-aws-modules)

### Usage
<!--- BEGIN_USAGE --->
```hcl
module "aks" {
  source                          = "../"
  aks_name                       = "devops3189"
  rg_name                        = "app_infra"
  rg_location                    = "West Europe"
  dns_prefix                     = "basic"
  agent_name                     = "aksnodepool1"
  node_count                     = "1"
  node_type                      = "Standard_D2_v2"
  node_os_disk_size              = "30"
  #aks_version                    = "1.18.14"
  network_plugin                 = "azure"
}
```
<!--- END_USAGE --->

<!--- BEGIN_TF_DOCS --->
## Requirements

No requirements.

## Providers

No provider.

## Modules

| Name | Source | Version |
|------|--------|---------|
| aks | ./modules/aks |  |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| aks\_name | aks cluster name | `string` | n/a | yes |
| dns\_prefix | dns name | `string` | n/a | yes |
| rg\_location | resource group location | `string` | n/a | yes |
| rg\_name | resource group name | `string` | n/a | yes |
| agent\_name | n/a | `string` | `"akspool01"` | no |
| network\_plugin | n/a | `string` | `"azure"` | no |
| node\_count | n/a | `number` | `1` | no |
| node\_os\_disk\_size | n/a | `number` | `30` | no |
| node\_type | n/a | `string` | `"Standard_D2_v2"` | no |

## Outputs

No output.

<!--- END_TF_DOCS --->
